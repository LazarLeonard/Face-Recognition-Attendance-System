#import libraries
import cv2
import numpy as np
import pandas as pd
import tkinter as tk
from tkinter import *
from PIL import Image
import os
import csv
import datetime
import time

#O functie ce determina daca inputul este numeric,val = valoarea de verificat,daca input este numeric -> "True" else "False"
def is_number(val):
    try:
        float(val)
        return True
    except ValueError:
        pass
    try:
        import unicodedata
        unicodedata.numeric(val)
        return True
    except (TypeError, ValueError):
        pass 
    return False



#Functie in care se va extrage data set-ul
def TakeImages():       
    #Se verifica daca inputul introdus indeplineste conditiile din functia de mai sus 
    Id=(txt.get())
    name=(txt2.get())
    if(is_number(Id) and name.isalpha()):
        #daca Id ul este numeric iar numele este alfabetic,se va deschide camera device-ului
        cam = cv2.VideoCapture(0)
        #Folosim clasificatorul Haar feature-based cascade 
        harcascadePath = "haarcascade_frontalface_default.xml"
        #Se incarca haar cascade face detector from
        detector=cv2.CascadeClassifier(harcascadePath)
        #Variabila pentru a stoca numarul de sample uri ce vor fi inregistrate in urma extragerii data set-ului
        sampleNum=0
        while(True):
            ret, img = cam.read()
            #Convert to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            #Sunt detectate cadre de diferite dimensiuni, lista dreptunghiurilor fețelor
            faceSamples = detector.detectMultiScale(gray, 1.3, 5)
            #Loop pt fiecare facesample
            for (x,y,w,h) in faceSamples:
                # Se decupeaza imaginea intr-un dreptunghi
                cv2.rectangle(img,(x,y),(x+w,y+h),(0, 255, 0), 3)        
                #se incrementeaza samplenum
                sampleNum=sampleNum+1
                #Fata capturata se salveaza drept dataset in folderul Dataset
                cv2.imwrite("Dataset\ "+name +"."+Id +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
                # Se deschide cadrul video in care fata persoanei respectiva este incadrata intr-un dreptunghi 
                cv2.imshow('frame',img)
            #O poza va fi facuta la fiecare 0,1 secunde
            if cv2.waitKey(100) & 0xFF == ord('q'):
                break
            # break daca numarul de mostre este mai mare de 40
            elif sampleNum>40:
                break
        #cadrul video se opreste
        cam.release()
        #toate ferestrele se inchid
        cv2.destroyAllWindows() 
        #In urma data setului colectat(40 de imagini pentru fiecare utilizator nou inregistrat) va aparea o notificare cu nr Id-ului inregistrat si numele utilizatorului
        res = "Imaginile au fost salvate pentru \n ID = " + Id +" Nume = "+ name
        #Un sir pt nr de id uri si nume
        row = [Id , name]
        #Datele vor fi salvate in folderul de mai jos in csvFile,pe fiecare coloana vor aparea id ul si numele data setului extras
        with open('DetaliiPersoane\DetaliiPersoane.csv','a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row)
        csvFile.close()
        msg.configure(text= res)
    else:
        #Daca numele va fi introdus intr-un mod eronat utilizatorul va fi atentionat printr-o notificare
        if(is_number(Id)):
            res = "Introduceti un nume alfabetic"
            msg.configure(text= res)
        #Verifica daca id-ul este numeric in caz contrat utilizatorul va fi atentionat printr-o notificare
        if(name.isalpha()):
            res = "Introduceti un ID numeric"
            msg.configure(text= res)
    
def TrainImages():
    #Algoritmul LBPH pt antrenarea datasetului extras,imaginile vor si salvate in folderul destinat iar daca operatiunea s-a desfasurat cu succes se va genera un fisier yml cu toate datele de training
    recognizer = cv2.face_LBPHFaceRecognizer.create()
    harcascadePath = "haarcascade_frontalface_default.xml"
    detector =cv2.CascadeClassifier(harcascadePath)
    faceSamples,Id = getImagesAndLabels("Dataset")
    recognizer.train(faceSamples, np.array(Id))
    recognizer.save("TrainingImageLabel\Trainner.yml")
    res = "Dataset Antrenat!"
    msg.configure(text= res)

def getImagesAndLabels(path):
    #gaseste calea absoluta a imagePathurilor dintr-o lista de imagePath
    imagePaths=[os.path.join(path,f) for f in os.listdir(path)] 

    #creeaza o lista goala de fete
    faceSamples=[]
    #creeaza o lista goala de Id - uri
    Ids=[]
    #Se va realiza un loop prin toate imaginile antrenate
    for imagePath in imagePaths:
        # Read the image and convert to grayscale. All, if not most, algorithms REQUIRE the images
		# to be grayscaled in order to capture the contour of the face more easily
        image_pil=Image.open(imagePath).convert('L')
        # Convert the image format into numpy array - this is how OpenCV handles facial structure
        imageNp=np.array(image_pil,'uint8')
        #Obtinem Id ul din fiecare imagine
        Id=int(os.path.split(imagePath)[-1].split(".")[1])
        #extrage fata din Dataset sample
        faceSamples.append(imageNp)
        Ids.append(Id)        
    return faceSamples,Ids

def TrackImages():
    #LBPHf Algorithm
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    #Citeste fisierul yml rezultat in urma datasetului antrenat
    recognizer.read("TrainingImageLabel\Trainner.yml")
    #Folosim clasificatorul Haar feature-based cascade 
    harcascadePath = "haarcascade_frontalface_default.xml"
    #Detecteaza fata din imagine si returneaza fata persoanei respectiva
    faceCascade = cv2.CascadeClassifier(harcascadePath);
    #Citeste Id ul si numele persoanei din csv file    
    df=pd.read_csv("DetaliiPersoane\DetaliiPersoane.csv")
    cam = cv2.VideoCapture(0)
    font = cv2.FONT_HERSHEY_SIMPLEX   
    #Coloana de nume ce va contine id ul,numele,data si ora    
    col_names =  ['Id','Name','Date','Time']
    prezenta = pd.DataFrame(columns = col_names)    
    while True:
        ret, im =cam.read()
        gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        faceSamples=faceCascade.detectMultiScale(gray, 1.2,5)    
        for(x,y,w,h) in faceSamples:
            cv2.rectangle(im,(x,y),(x+w,y+h),(225,0,0),2)
            Id, conf = recognizer.predict(gray[y:y+h,x:x+w])
            cv2.rectangle(im, (x, y), (x + w, y + h), (0, 255, 0), 3)                                 
            if(conf < 45):
                #functie ce returneaza timpul prezent in ordinea urmatoare zile-luni-ani || ora,minutul,secunda
                ts = time.time()      
                date = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%y')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                aa=df.loc[df['Id'] == Id]['Name'].values
                tt=str(Id)+"-"+aa
                prezenta.loc[len(prezenta)] = [Id,aa,date,timeStamp]
                
            else:
                Id='Necunoscut'                
                tt=str(Id)
                #Daca nu exista nicio similaritate in fata detectata se vor salva un nr de imagini intr-un folder specific persoanele necunoscute sistemului  
            if(conf > 75):
                noOfFile=len(os.listdir("PersoaneNecunoscute"))+1
                cv2.imwrite("PersoaneNecunoscute\Image"+str(noOfFile) + ".jpg", im[y:y+h,x:x+w])            
            cv2.putText(im,str(tt),(x,y+h), font, 1,(255,255,255),2)        
        prezenta=prezenta.drop_duplicates(subset=['Id'],keep='first')    
        cv2.imshow('im',im) 
        #Daca se va apasa tasta Q se va stoca aparitia la momentul respectiv al persoanei ce utilizeaza aplicatia
        if (cv2.waitKey(1)==ord('q')):
            break
    ts = time.time()  
    #Se va salva data si ora la momentul inchiderii camerei   
    date = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%y')
    timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
    Hour,Minute,Second=timeStamp.split(":")
    #Se salveaza data si ora in folderul specific in csv file
    fileName="Prezenta\Prezenta_"+date+"_"+Hour+"-"+Minute+"-"+Second+".csv"
    prezenta.to_csv(fileName,index=False)
    #cadrul video se opreste
    cam.release()
    #toate ferestrele se inchid
    cv2.destroyAllWindows()
    #Se printeaza prezenta
    res=prezenta
    msg2.configure(text= res)


window = tk.Tk()
window.title("Recunoastere_Faciala")

dialog_title = 'Iesi'

window.configure(background='sky blue')


window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)




msg = tk.Label(window, text="Identificarea in timp real dintr-un stream live a unor persoane" ,bg="sky blue"  ,fg="white"  ,width=50  ,height=3,font=('times', 30, 'italic bold underline')) 

msg.place(x=200, y=20)

label = tk.Label(window, text="Introduceti ID",width=20  ,height=2  ,fg="sky blue"  ,bg="white" ,font=('times', 15, ' bold ') ) 
label.place(x=400, y=200)

txt = tk.Entry(window,width=25  ,bg="white" ,fg="sky blue",font=('times', 15, ' bold '))
txt.place(x=700, y=215)

labeltwo = tk.Label(window, text="Introduceti Nume",width=20  ,fg="sky blue"  ,bg="white" ,height=2 ,font=('times', 15, ' bold ')) 
labeltwo.place(x=400, y=300)

txt2 = tk.Entry(window,width=25  ,bg="white"  ,fg="sky blue",font=('times', 15, ' bold ')  )
txt2.place(x=700, y=315)

labelthree = tk.Label(window, text="Notificari : ",width=20  ,fg="sky blue"  ,bg="white"  ,height=2 ,font=('times', 15, ' bold underline ')) 
labelthree.place(x=400, y=400)

msg = tk.Label(window, text="" ,bg="white"  ,fg="sky blue"  ,width=22  ,height=2, activebackground = "white" ,font=('times', 15, ' bold ')) 
msg.place(x=700, y=400)

labelthreee = tk.Label(window, text="Prezenta : ",width=20  ,fg="sky blue"  ,bg="white"  ,height=3 ,font=('times', 15, ' bold  underline')) 
labelthreee.place(x=400, y=650)


msg2 = tk.Label(window, text="" ,fg="sky blue"   ,bg="white",activeforeground = "green",width=30  ,height=3  ,font=('times', 15, ' bold ')) 
msg2.place(x=700, y=650)

takeImg = tk.Button(window, text="Extrage setul de date", command=TakeImages  ,fg="sky blue"  ,bg="white"  ,width=20  ,height=3, activebackground = "sky blue" ,font=('times', 15, ' bold '))
takeImg.place(x=200, y=500)
trainImg = tk.Button(window, text="Antreneaza setul de date", command=TrainImages  ,fg="sky blue"  ,bg="white"  ,width=20  ,height=3, activebackground = "sky blue" ,font=('times', 15, ' bold '))
trainImg.place(x=500, y=500)
trackImg = tk.Button(window, text="Identifica persoana", command=TrackImages  ,fg="sky blue"  ,bg="white"  ,width=20  ,height=3, activebackground = "sky blue" ,font=('times', 15, ' bold '))
trackImg.place(x=800, y=500)
quitWindow = tk.Button(window, text="Iesi", command=window.destroy  ,fg="sky blue"  ,bg="white"  ,width=20  ,height=3, activebackground = "sky blue" ,font=('times', 15, ' bold '))
quitWindow.place(x=1100, y=500)



window.mainloop()